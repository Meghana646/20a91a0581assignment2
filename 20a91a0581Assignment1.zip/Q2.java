import java.util.*;
class Q2{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int a[]=new int[n];

        for(int i=0;i<n;i++)
        a[i]=sc.nextInt();

        HashSet<Integer>hs=new HashSet<>();

        for(int ele:a) hs.add(ele);

        for(int ele:hs) System.out.print(ele+" ");
    }
}