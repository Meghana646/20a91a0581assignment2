import java.util.*;
class Product{
	static Scanner sc=new Scanner(System.in);
    static void addproducts(ArrayList<String> pl,ArrayList<ArrayList<String>> pd,ArrayList<Integer> pc)
    {
        System.out.println("Enter Product name: ");
        String pname=sc.next();
        pl.add(pname);
        System.out.println("Enter Product quantity: ");
        int quant=sc.nextInt();
        System.out.println("Enter Specifications: ");
        sc.nextLine();
        String sp=sc.nextLine();
        System.out.println("Enter Cost: ");
        String cost=sc.next();
        ArrayList<String> a=new ArrayList<>();
        a.add(sp);
        a.add(cost);
        a.add(Integer.toString(quant));
        pd.add(a);
        pc.add(quant);
    }
    static void viewproductdetails(ArrayList<String> pl,ArrayList<ArrayList<String>> pd,ArrayList<Integer> pc)
    {
        for(int i=0;i<pl.size();i++)
        {
            System.out.print(pl.get(i)+"  ");
            String d="";
            for(int j=0;j<pd.get(i).size();j++)
            d+=pd.get(i).get(j)+" ";
            System.out.print(d);
            System.out.println();
        }
    }
    static void productlist(ArrayList<String> pl,ArrayList<ArrayList<String>> pd,ArrayList<Integer> pc)
    {
        System.out.println("Enter productname to get count: ");
        String name=sc.next();
        int k=pl.indexOf(name);
        System.out.println(pl.get(k)+" "+pc.get(k));
    }
    static void editproduct(ArrayList<String> pl,ArrayList<ArrayList<String>> pd,ArrayList<Integer> pc)
    {
        System.out.println("Enter productname to edit details: ");
        String p=sc.next();
        int k=pl.indexOf(p);
        System.out.println("Enter product quantity: ");
        int quant=sc.nextInt();
        System.out.println("Enter Specifications: ");
        sc.nextLine();
        String sp=sc.nextLine();
        System.out.println("Enter Cost: ");
        String cost=sc.next();
        ArrayList<String> a=new ArrayList<>();
        a.add(sp);
        a.add(cost);
        a.add(Integer.toString(quant));
        pd.set(k, a);
        pc.set(k,quant);
    }
    static void productcount(ArrayList<String> pl,ArrayList<Integer> pc)
    {
        System.out.println("Enter productname to get count: ");
        String pname=sc.next();
        int i=pl.indexOf(pname);
        System.out.println(pl.get(i)+"    "+pc.get(i));
    }
    static void updateinventory(ArrayList<String> pl,ArrayList<ArrayList<String>> pd,ArrayList<Integer> pc)
    {
        System.out.println("Enter 1 to add and 2 to delete product quantity: ");
        int choice=sc.nextInt();
        if(choice==1)
        {
            System.out.println("Enter product name: ");
            String pname=sc.next();
            System.out.println("Enter no of items to add: ");
            int n=sc.nextInt();
            int i=pl.indexOf(pname);
            pc.set(i,pc.get(i)+n);
            int m=pc.get(i);
            pd.get(i).set(2,Integer.toString(m));
        }
        else
        {
            System.out.println("Enter product name: ");
            String pname=sc.next();
            System.out.println("Enter no of items to add: ");
            int n=sc.nextInt();
            int i=pl.indexOf(pname);
            pc.set(i,pc.get(i)-n);
            int m=pc.get(i);
            pd.get(i).set(2,Integer.toString(m));
        }
    }
}
class Q4
{
	static Scanner sc=new Scanner(System.in);
    public static void main(String[] args) {
    	Product p=new Product();
        ArrayList<String> pl=new ArrayList<>();
        ArrayList<ArrayList<String>> pd=new ArrayList<>();
        ArrayList<Integer> pc=new ArrayList<>();
        int s;
        int i=0;
        while(true) {
			System.out.print("choose one \n1.Add Products\n2.Product List\n3.Product count\n4.Product Details\n5.Edit Product\n6.update Quantities\n7.Exit\n");
			s=sc.nextInt();
			switch(s) {
			case 1:
				p.addproducts(pl,pd,pc);
				i+=1;
				break;
			case 2:
				p.viewproductdetails(pl, pd,pc);
				break;
			case 3:
				p.productcount(pl,pc);
				break;
			case 4:
				p.productlist(pl,pd,pc);
				break;
			case 5:
				p.editproduct(pl,pd,pc);
				break;
			case 6:
				p.updateinventory(pl,pd,pc);
				break;
			case 7:
				break;
			}
			if(s==7) {
				break;
			}
		}
    }
}