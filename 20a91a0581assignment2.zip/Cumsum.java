import java.util.*;
class Cumsum
{
public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the size of array");
    int n=sc.nextInt();
    System.out.println("Enter the Elements into Array:");
    int arr[]=new int[n];
    for(int i=0;i<n;i++)
    arr[i]=sc.nextInt();
    System.out.print(arr[0]+" ");
    for(int i=1;i<n;i++)
    {
        arr[i]=arr[i]+arr[i-1];
        System.out.print(arr[i]+" ");
    }
     sc.close();
}
}