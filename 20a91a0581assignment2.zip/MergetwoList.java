import java.util.*;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}


public class MergetwoList {
    static Node createList(int a[])
    {Node head=null;
        for(int i=0;i<a.length;i++)
        {
            Node j=new Node(a[i]);
            if(head==null)
            head=j;
            else{
                Node ptr=head;
                while(ptr.next!=null)
                {
                    ptr=ptr.next;
                }
                ptr.next=j;
            }
        }
        return head;
    }
    static void printList(Node head)
    {
        Node ptr=head;
        while(ptr.next!=null)
        {
            System.out.print(ptr.data+" ");
            ptr=ptr.next;
        }
        System.out.print(ptr.data+"\n");
        System.out.println();
    }
    static Node merge(Node h1,Node h2)
    {
        ArrayList<Integer> arr=new ArrayList<>();
        Node ptr=h1;
        while(ptr.next!=null)
        {
            arr.add(ptr.data);
            ptr=ptr.next;
        }
        arr.add(ptr.data);
        ptr.next=h2;
        ptr=ptr.next;
        while(ptr!=null)
        {
            arr.add(ptr.data);
            ptr=ptr.next;
        }
        ptr=h1;
        Collections.sort(arr);
        for(int i=0;i<arr.size();i++)
        {
            ptr.data=arr.get(i);
            ptr=ptr.next;
        }
        return h1;
    }
   
    public static void main(String[] args) {
        Scanner  sc=new Scanner(System.in);
        System.out.println("enter length of first list");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("enter first list data");
        for(int i=0;i<n;i++)
        a[i]=sc.nextInt();
        System.out.println("enter length  of second list");
        int m=sc.nextInt();
        int b[]=new int[m];
        System.out.println("enter second list data");
        for(int i=0;i<m;i++)
        b[i]=sc.nextInt();
    Node l1=createList(a);
      Node l2=createList(b);
       
       Node head=merge(l1, l2);
       printList(head);
       sc.close();
    }
}