import java.util.*;
class Node{
    int data;
    Node next;
    Node(int x){
        this.data=x;
        this.next=null;
    }
}
public class RemoveDuplicates {
    static Node createList(int arr[])
    {Node h=null;
        for(int i=0;i<arr.length;i++)
        {
            Node j=new Node(arr[i]);
            if(h==null)
            h=j;
            else{
                Node ptr=h;
                while(ptr.next!=null)
                {
                    ptr=ptr.next;
                }
                ptr.next=j;
            }
        }
        return h;
    }
    static void printList(Node h)
    {
        Node ptr=h;
        while(ptr.next!=null)
        {
            System.out.print(ptr.data+" ");
            ptr=ptr.next;
        }
        System.out.print(ptr.data+"\n");
        System.out.println();
    }
    static Node removeDuplicates(Node h){
        Node ptr=h;
        Node pre=ptr;
        ArrayList<Integer> hs=new ArrayList<>();
        while(ptr!=null)
        {
            if(!hs.contains(ptr.data)){
                hs.add(ptr.data);
                pre=ptr;
                ptr=ptr.next;
            }
            else
            {
                pre.next=ptr.next;
                ptr=ptr.next;
            }
        }
        return h;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the no of nodes");
        int n=sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter values:");
        for(int i=0;i<n;i++)
        arr[i]=sc.nextInt();
        Node h=createList(arr);
        System.out.println("Before Removing Duplicates");
        printList(h);
        System.out.println("After Removing Duplicates:");
        h=removeDuplicates(h);
        printList(h);
sc.close();
    }
}